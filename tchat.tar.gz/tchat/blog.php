<!DOCTYPE html>
<html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<head>
	<title>Yotsublog</title>
</head>
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">-->
<audio></audio>
<body class ="container" style="background-image: url(yotsu.png)">
	<link rel="stylesheet" type="text/css" href="style.css">
	<!--<div class="container-fluid">
		<fieldset>
			<legend><h1>Bienvenue chez Vincent</h1></legend>
			<div class="rows">
				<div class="col-md-12">
				<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."<br><strong>Cicéron</strong></p>
				</div>
			</div>
		</fieldset>	
	</div>-->
	<div>
		<form  action="action.php" method="POST">
			<fieldset class="inCom">
			<legend>Chat</legend>
			<input type="text" name="auteur" placeholder="笔名。。。。。。"><br>
			<textarea rows="5" cols="50" placeholder="评论。。。。。。" name = "contenu"></textarea><br>
			<input type="submit" name="submit" value="发送">
		</form>
		<div>
			<fieldset class="outCom">
			<legend><h2>Fil de Discussion</h2></legend>
			<?php
				$auteur = $_POST["auteur"];
				$contenu = $_POST["contenu"];	
				$nom_serv ="localhost";
				$nom_base ="blog";
				$identifiant ="root";
				// don't forget you password //
				$mot_de_passe ="";
				?>
				<div >
			<?php

				try{
					$connexion = new PDO("mysql:host=$nom_serv;dbname=$nom_base",
											$identifiant,
											$mot_de_passe);
					$connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
					}
				catch (PDOException $e) {
					echo "Echec de connexion et d'enregistrement: " . $e-> 
					getMessage();
										}
				$response = $connexion->query('SELECT * FROM commentaires');
				$response-> execute();
				while ($donnees = $response->fetch()){
					$date = $donnees['date'];
					$datej = date('d M', strtotime($date));
					$dateh = date('H:i:s', strtotime($date));
					
					echo "<fieldset><legend>" . "posté par " . htmlspecialchars($donnees['auteur']) . " " . "le " . $datej . " à " . $dateh . "</legend>" . "<p>" . htmlspecialchars($donnees['contenu']) . "<p></fieldset>";
													}
	 		?>
	 			</div>
	 		</div>
	 		</fieldset>
	</div>
</body>
</html>