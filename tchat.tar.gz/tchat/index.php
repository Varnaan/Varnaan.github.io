<!DOCTYPE html>
<html>
<head>
	<title>Log-In</title>
</head>
<body>
	<form action="blog.php" method="POST">
		<input type="text" name="logiun" placeholder="username">
		<input type="password" name="password" placeholder="password"><br>
		<input type="submit" name="login" value="log-in">
		
	</form>
</body>
</html>
<?php
 ?>