-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 08, 2017 at 03:19 PM
-- Server version: 5.7.20-0ubuntu0.16.04.1
-- PHP Version: 7.1.10-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `billets`
--

CREATE TABLE `billets` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `contenu` text NOT NULL,
  `auteur` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `commentaires`
--

CREATE TABLE `commentaires` (
  `id` int(11) NOT NULL,
  `auteur` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT 'Anonymous',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `contenu` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `commentaires`
--

INSERT INTO `commentaires` (`id`, `auteur`, `date`, `contenu`) VALUES
(89, 'Vincent', '2017-11-14 15:41:00', 'Salut Ã  tous !'),
(90, 'Angular', '2017-11-14 15:42:25', 'Il fait chaud ici tu trouve pas ?'),
(91, 'Vincent', '2017-11-14 15:43:37', 'Ã§a gaze'),
(92, 'Rocket', '2017-11-14 15:43:52', 'Hey rasta ! T est mort ?\r\n'),
(93, 'Vincent', '2017-11-14 15:45:04', 't\'es...'),
(101, 'Deborah', '2017-11-14 16:02:01', 'Ton fond en css est rÃ©ussi.\r\nTu a fini par le maÃ®triser !'),
(102, 'Sandy', '2017-11-14 16:03:19', 'pas mal pas mal ce blog.....:)'),
(103, 'Vincent', '2017-11-14 16:05:27', '@Sandy, @Deborah\r\nMerci ! :^)'),
(104, 'Deborah', '2017-11-14 16:14:24', 'La fille au trÃ¨fle est mignione');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billets`
--
ALTER TABLE `billets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commentaires`
--
ALTER TABLE `commentaires`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billets`
--
ALTER TABLE `billets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `commentaires`
--
ALTER TABLE `commentaires`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
