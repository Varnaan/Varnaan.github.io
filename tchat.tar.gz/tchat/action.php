
<body class="action">
	<link rel="stylesheet" type="text/css" href="style.css">
	<div class="merci">
	<!--<span><p>Merci pour votre commentaire!</p></span>-->
	<form action="index.php">
	<br><input type="submit" href="index.php" value="返回" height="10" width="10"></input>
	</form>
	</div>
	<title>Yotsu谢谢</title>
	<?php
	$auteur = $_POST["auteur"];
	$contenu = $_POST["contenu"];
	

	$nom_serv ="localhost";
	$nom_base ="blog";
	$identifiant ="root";
	// don't forget you password //
	$mot_de_passe ="";

	if ($auteur == "" || $contenu == "") {
		echo "username and/or content field cannot be empty";

	}
	else{
		echo "Message envoyé !";
		try{
			$connexion = new PDO("mysql:host=$nom_serv;dbname=$nom_base",
								$identifiant,
								$mot_de_passe);
			
			$connexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		

			$req= "INSERT INTO commentaires (auteur, contenu)
							VALUES('$auteur','$contenu')";

			$connexion->exec($req);
			
		}

		catch (PDOException $e) {
			echo "Echec de connexion et d'enregistrement: " . $e-> 
				getMessage();
		}
	}
	

	/*$response = $connexion->query('SELECT * FROM commentaires');

	$response-> execute();

	while ($donnees = $response->fetch()){
		echo "<p>" . htmlspecialchars($donnees['auteur']) . ":" ." " . htmlspecialchars($donnees['contenu']) . "<p>";
	}*/

	
	 ?>
	 </body>